
import { toggleTab } from '../common/ui.js'

document.addEventListener('DOMContentLoaded', () => {
  console.log('🟢 sub.js 로드됨!')
  toggleTab('.sub-tab')
})
